#include "game_object.h"

GameObject::GameObject(){}

GameObject::~GameObject(){}

void GameObject::obj_init(const char* graphic, SDL_Renderer* ren){
  //initializing the player movement
  obj_rect.x = 5;
  obj_rect.y = 0;
  //initializing the size of the player square
  obj_rect.w = start_width/X_FRAMES;
  obj_rect.h = start_height/Y_FRAMES;
  //making our sprite object and initializing
  obj_sprite = new GameSprite();
  obj_sprite->sprite_init(graphic,ren,X_FRAMES,100,start_width,start_height);
  //making the obj_graphic to be same as the sprites graphic
  obj_graphic = obj_sprite->get_spriteText();
}

void GameObject::obj_update(){
  //if the player goes out of bounds i want to slow them down
  if(obj_rect.x < (LEFT_BOUND - obj_rect.w/2)) x_val += 0;
  if(obj_rect.x > (RIGHT_BOUND - obj_rect.w/2)) x_val += 0;
  if(obj_rect.y > (DOWN_BOUND - obj_rect.h/2)) y_val += 0;
  if(obj_rect.y < (UP_BOUND - obj_rect.h/2)) y_val += 0;

  //if the player goes out of bounds i want to stop their movement from
  //going off screen
  if(obj_rect.x < (LEFT_BOUND - obj_rect.w/2)) obj_rect.x = (LEFT_BOUND-obj_rect.w/2);
  if(obj_rect.x > (RIGHT_BOUND - obj_rect.w/2))  obj_rect.x = (RIGHT_BOUND-obj_rect.w/2);
  if(obj_rect.y > (DOWN_BOUND - 2*obj_rect.h))  obj_rect.y =  (DOWN_BOUND-2*obj_rect.h);
  if(obj_rect.y < (UP_BOUND - obj_rect.h/2)) obj_rect.y = (UP_BOUND-obj_rect.h/2);

  //keeps the velocity from going too fast
  if(x_val<(-1*MAX_VELO)) x_val = -1*MAX_VELO;
  if(x_val>(MAX_VELO))    x_val = MAX_VELO;
  if(y_val<(-1*MAX_VELO)) y_val= -1*MAX_VELO;
  if(y_val>(MAX_VELO))    y_val = MAX_VELO;

  //update the player movement
  obj_rect.x += x_val;
  obj_rect.y += y_val;

  //determine which state we are in based off of the movement
  if(x_val == 0 && y_val ==0){
    state = IDLE;
  }
  if(x_val>0){
    state = MOVE_RIGHT;
  }
  if(x_val<0){
    state = MOVE_LEFT;
  }
  if(y_val<0){
    state = MOVE_UP;
  }
  if(y_val>0){
    state = MOVE_DOWN;
  }
  //upadate our sprite to be in the correct frame
  frame_rect = obj_sprite->sprite_update(state,start_height);


}

//render in our player movement;
//i stayed with the origianal rendercopy bc i made my own sprite and forgot
//we could flip horizontal movement
void GameObject::obj_render(SDL_Renderer* ren){
  SDL_RenderCopy(ren, obj_graphic, &frame_rect, &obj_rect);
}
//clean up
void GameObject::obj_quit(){
  SDL_DestroyTexture(obj_graphic);
}

// these are helper functions used to get and set velocity values amongst
// other classes

int GameObject::obj_get_x_value(){
  return x_val;
}

void GameObject::obj_set_x_value(int x_vel){
  x_val = x_vel;
}

int GameObject::obj_get_y_value(){
  return y_val;
}

void GameObject::obj_set_y_value(int y_vel){
  y_val = y_vel;
}
